const d = new Date();
document.getElementById("date").innerHTML = d;
